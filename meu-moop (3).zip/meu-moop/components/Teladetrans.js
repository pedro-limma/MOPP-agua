import * as React from 'react';
import { Text, View, StyleSheet, Image,ImageBackground } from 'react-native';

export default function Telatrans() {
  return (
    <ImageBackground 
    source={require('../assets/teladetransicao.png')}
    style={{width: '100%', height: '100%' , }}>
    
    </ImageBackground>
  );
}